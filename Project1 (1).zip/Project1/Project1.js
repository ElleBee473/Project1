var name = 'Lloyd';
console.log(name);
var hobby = "Tennis";
var age = "13";

var a = 3;
var b = 2;

//Addition
var a = 3.3, b = 2.5;
var c = a + b;
console.log(c);
///Operators
///Subtraction
var d = a - b;
console.log(d);

var e = 50%15;

console.log(e);

///Strings
var food =                 'burger ';
var drink =                'soda';

console.log(food + drink);

//Bio
var firstName = 'Lloyd '
var lastName = 'Irvin'
var fullName = firstName.concat(lastName)

console.log("My name is  " + fullName);